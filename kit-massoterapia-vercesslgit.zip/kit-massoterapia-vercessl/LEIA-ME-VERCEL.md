# Publicação no Vercel

Este projeto é um site estático: `index.html` fica na raiz, junto da pasta `assets/`. Não precisa de etapa de build, framework, banco de dados ou dependências npm.

## Publicar pela CLI

1. Extraia este ZIP em uma pasta.
2. Abra um terminal nessa pasta (a mesma onde estão `index.html` e `vercel.json`).
3. Instale a CLI do Vercel, se ainda não estiver instalada:

   ```bash
   npm install --global vercel
   ```

4. Autentique-se e publique em produção:

   ```bash
   vercel login
   vercel --prod
   ```

Na primeira execução, a CLI pedirá para confirmar/criar o projeto e selecionar a conta ou equipe. Mantenha a raiz do projeto como o diretório de publicação.

## Publicar por Git

Envie o conteúdo desta pasta para um repositório Git e importe-o pelo painel do Vercel. Como preset, selecione **Other**; deixe o comando de build vazio e use a própria raiz do projeto como diretório de saída.

## Conteúdo do pacote

- `index.html` — página de Massoterapia com cronômetro de 1 hora reiniciado por carregamento e depoimentos em carrossel contínuo.
- `assets/` — imagens e demais recursos referenciados pela página.
- `vercel.json` — configuração mínima para servir a página com URLs limpas.
