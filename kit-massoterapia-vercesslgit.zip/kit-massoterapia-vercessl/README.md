# Kit Massoterapia Organizada — site estático

O ponto de entrada é `index.html`. Os recursos estão em `assets/`. Para publicar no Vercel, veja [LEIA-ME-VERCEL.md](LEIA-ME-VERCEL.md).
